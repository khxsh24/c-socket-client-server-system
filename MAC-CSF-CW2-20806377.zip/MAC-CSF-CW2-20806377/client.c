// Client.c  (Mac / POSIX version)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>         // close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
    const char *server_ip = "127.0.0.1";
    int port = PORT;

    if (argc >= 2) {
        server_ip = argv[1];
    }
    if (argc >= 3) {
        port = atoi(argv[2]);
    }

    int client_fd;
    struct sockaddr_in server_address;
    char buffer[BUF_SIZE] = {0};
    char message[BUF_SIZE];

    // Create the socket
    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (client_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port   = htons(port);
    server_address.sin_addr.s_addr = inet_addr(server_ip);

    // Connect to the server
    if (connect(client_fd, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("connect");
        close(client_fd);
        exit(EXIT_FAILURE);
    }
    printf("Connected to the server (%s:%d).\n", server_ip, port);

    while (1) { // loop to execute multiple messages
        printf("Enter your message for the server to receive (type 'Exit Server' to quit): ");
        if (!fgets(message, sizeof(message), stdin)) {
            break;
        }
        message[strcspn(message, "\n")] = '\0';

        if (strcmp(message, "Exit Server") == 0) {
            printf("Exiting the server...\n");
            break;
        }

        if (send(client_fd, message, strlen(message), 0) < 0) {
            perror("send");
            break;
        }
        printf("Sent to server: %s\n", message);

        int bytes_received = recv(client_fd, buffer, sizeof(buffer) - 1, 0);
        if (bytes_received > 0) {
            buffer[bytes_received] = '\0';
            printf("Received from server: %s\n", buffer);
        } else if (bytes_received == 0) {
            printf("Server closed the connection.\n");
            break;
        } else {
            perror("recv");
            break;
        }
    }

    close(client_fd);
    return 0;
}