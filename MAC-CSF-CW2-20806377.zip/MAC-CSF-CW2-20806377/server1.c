// Server1.c (macOS / POSIX)
// Task 1: reverse the client's message and uppercase letters.
// If message contains any non-alphanumeric character -> return error.
// Only terminate if client sends exactly: "Exit Server"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024
#define DEFAULT_PORT 8080

static int is_alnum_only(const char *s) {
    for (int i = 0; s[i] != '\0'; i++) {
        if (!isalnum((unsigned char)s[i])) return 0;
    }
    return 1;
}

static void uppercase_and_reverse(char *s) {
    int n = (int)strlen(s);
    for (int i = 0; i < n; i++) {
        if (isalpha((unsigned char)s[i])) s[i] = (char)toupper((unsigned char)s[i]);
    }
    for (int i = 0, j = n - 1; i < j; i++, j--) {
        char tmp = s[i];
        s[i] = s[j];
        s[j] = tmp;
    }
}

static void strip_crlf(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[n - 1] = '\0';
        n--;
    }
}

int main(int argc, char *argv[]) {
    int port = DEFAULT_PORT;
    if (argc >= 2) port = atoi(argv[1]);

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((uint16_t)port);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 1) < 0) {
        perror("listen");
        close(server_fd);
        return 1;
    }

    printf("Server1 listening on port %d...\n", port);

    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    int client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
    if (client_fd < 0) { perror("accept"); close(server_fd); return 1; }

    char buffer[BUF_SIZE];

    // Task 1 doesn't force multiple requests, but supporting it doesn't hurt.
    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int bytes = (int)recv(client_fd, buffer, sizeof(buffer) - 1, 0);
        if (bytes <= 0) {
            printf("Client disconnected.\n");
            break;
        }

        buffer[bytes] = '\0';
        strip_crlf(buffer);

        printf("Received from client: %s\n", buffer);

        if (strcmp(buffer, "Exit Server") == 0) {
            const char *bye = "Server closed the connection.\r\n";
            send(client_fd, bye, (int)strlen(bye), 0);
            printf("Exit Server received. Shutting down Server1.\n");
            break;
        }

        if (!is_alnum_only(buffer)) {
            const char *err =
                "Error: Only alphanumeric format message are allowed.\r\n";
            send(client_fd, err, (int)strlen(err), 0);
            printf("Sent error to client (non-alphanumeric).\n");
            continue;
        }

        uppercase_and_reverse(buffer);
        send(client_fd, buffer, (int)strlen(buffer), 0);
        send(client_fd, "\r\n", 2, 0); // clean line ending for the client display
        printf("Sent to client: %s\n", buffer);
    }

    close(client_fd);
    close(server_fd);
    return 0;
}