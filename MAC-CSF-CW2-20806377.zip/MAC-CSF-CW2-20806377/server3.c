// Server3.c (macOS / POSIX)
// Task 3: handle command "Date" and return:
// "Day Mon DD HH:MM:SS YYYY GMT + 8\r\n"
// Any other input -> error message (same style as Task 2).
// Only terminate if client sends exactly: "Exit Server"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024
#define DEFAULT_PORT 8080

static void strip_crlf(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[n - 1] = '\0';
        n--;
    }
}

static void make_date_line(char *out, size_t out_sz) {
    time_t now = time(NULL);
    struct tm *lt = localtime(&now); // server assumed in Malaysia
    char temp[128];
    strftime(temp, sizeof(temp), "%a %b %d %H:%M:%S %Y", lt);
    snprintf(out, out_sz, "%s GMT + 8\r\n", temp);
}

int main(int argc, char *argv[]) {
    int port = DEFAULT_PORT;
    if (argc >= 2) port = atoi(argv[1]);

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((uint16_t)port);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 3) < 0) {
        perror("listen");
        close(server_fd);
        return 1;
    }

    printf("Server3 listening on port %d...\n", port);

    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);

    while (1) {
        int client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) { perror("accept"); continue; }

        // Task 2 style info kept (Server3 is modified from Server2)
        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &client_addr.sin_addr, ip, sizeof(ip));
        printf("Connected client IP: %s\n", ip);
        printf("Client port: %d\n", ntohs(client_addr.sin_port));

        char buffer[BUF_SIZE];

        while (1) {
            memset(buffer, 0, sizeof(buffer));
            int bytes = (int)recv(client_fd, buffer, sizeof(buffer) - 1, 0);
            if (bytes <= 0) {
                printf("Client disconnected.\n");
                break;
            }

            buffer[bytes] = '\0';
            strip_crlf(buffer);

            printf("Length of message: %zu\n", strlen(buffer));
            printf("Received: %s\n", buffer);

            if (strcmp(buffer, "Exit Server") == 0) {
                const char *bye = "Server closed the connection.\r\n";
                send(client_fd, bye, (int)strlen(bye), 0);
                printf("Exit Server received. Shutting down Server3.\n");
                close(client_fd);
                close(server_fd);
                return 0;
            }

            if (strcmp(buffer, "Date") == 0) {
                char line[256];
                make_date_line(line, sizeof(line));
                send(client_fd, line, (int)strlen(line), 0);
                printf("Sent date line: %s", line);
                continue;
            }

            // "error message as in task 2" (same idea + tells them to type alphanumeric)
            const char *err =
                "Error: Invalid input. Please key in an alphanumeric format message only.\r\n";
            send(client_fd, err, (int)strlen(err), 0);
            printf("Sent error to client.\n");
        }

        close(client_fd);
    }
}