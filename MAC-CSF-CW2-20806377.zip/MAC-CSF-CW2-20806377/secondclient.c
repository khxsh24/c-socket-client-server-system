// SecondClient.c  (Mac / POSIX version)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define BUF_SIZE 1024

// This function receives messages from the server
void *receive_messages(void *arg) {
    int sock = *(int *)arg;
    char buffer[BUF_SIZE] = {0};

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int bytes = recv(sock, buffer, sizeof(buffer) - 1, 0);
        if (bytes > 0) {
            buffer[bytes] = '\0';
            printf("\nMessage from Client 1: %s\n", buffer);
            printf("Enter message: ");
            fflush(stdout);
        } else {
            if (bytes == 0) {
                printf("\nServer closed the connection.\n");
            } else {
                perror("\nrecv");
            }
            break;
        }
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    const char *server_ip = "127.0.0.1";
    int port = PORT;

    if (argc >= 2) server_ip = argv[1];
    if (argc >= 3) port = atoi(argv[2]);

    int client_fd;
    struct sockaddr_in server_address;
    char buffer[BUF_SIZE] = {0};
    pthread_t recv_thread;

    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (client_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port   = htons(port);
    server_address.sin_addr.s_addr = inet_addr(server_ip);

    if (connect(client_fd, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("connect");
        close(client_fd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to the server.\n");

    if (pthread_create(&recv_thread, NULL, receive_messages, &client_fd) != 0) {
        perror("pthread_create");
        close(client_fd);
        exit(EXIT_FAILURE);
    }

    while (1) {
        printf("Enter message: ");
        if (!fgets(buffer, sizeof(buffer), stdin)) {
            break;
        }
        buffer[strcspn(buffer, "\n")] = '\0';

        if (strcmp(buffer, "Exit Server") == 0) {
            printf("Disconnecting...\n");
            break;
        }

        if (send(client_fd, buffer, strlen(buffer), 0) < 0) {
            perror("send");
            break;
        }
    }

    close(client_fd);
    pthread_cancel(recv_thread);
    pthread_join(recv_thread, NULL);
    return 0;
}