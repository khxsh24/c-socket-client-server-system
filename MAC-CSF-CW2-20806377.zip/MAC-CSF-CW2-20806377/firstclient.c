// FirstClient.c  (Mac / POSIX version)
// Chat client 1 for Server5.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define BUF_SIZE 1024

static volatile int running = 1;

// Thread to receive messages from server
void *receive_messages(void *arg) {
    int sock = *(int *)arg;
    char buffer[BUF_SIZE];

    while (running) {
        int bytes = recv(sock, buffer, sizeof(buffer) - 1, 0);
        if (bytes > 0) {
            buffer[bytes] = '\0';
            printf("\nMessage from Client 2: %s\n", buffer);
            printf("Enter message: ");
            fflush(stdout);
        } else {
            if (bytes == 0) {
                printf("\nServer closed the connection.\n");
            } else {
                perror("\nrecv");
            }
            running = 0;
            break;
        }
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    const char *server_ip = "127.0.0.1";
    int port = PORT;

    if (argc >= 2) server_ip = argv[1];
    if (argc >= 3) port = atoi(argv[2]);

    int sock;
    struct sockaddr_in server_address;
    char buffer[BUF_SIZE];
    pthread_t recv_thread;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family      = AF_INET;
    server_address.sin_port        = htons(port);
    server_address.sin_addr.s_addr = inet_addr(server_ip);

    if (connect(sock, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("connect");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server %s:%d\n", server_ip, port);

    if (pthread_create(&recv_thread, NULL, receive_messages, &sock) != 0) {
        perror("pthread_create");
        close(sock);
        exit(EXIT_FAILURE);
    }

    while (running) {
        printf("Enter message: ");
        if (!fgets(buffer, sizeof(buffer), stdin)) {
            break;
        }
        buffer[strcspn(buffer, "\n")] = '\0';

        if (send(sock, buffer, strlen(buffer), 0) < 0) {
            perror("send");
            break;
        }

        if (strcmp(buffer, "Exit Server") == 0) {
            printf("Disconnecting...\n");
            running = 0;
            break;
        }
    }

    close(sock);
    pthread_join(recv_thread, NULL);
    return 0;
}