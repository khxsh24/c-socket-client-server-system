// Server5.c  (Mac / POSIX version)
// Chat relay server for 2 clients.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define MAX_CLIENTS 2
#define BUF_SIZE 1024

typedef struct {
    int socket;       // socket from client
    int id;           // client id (1 or 2)
    int peer_socket;  // socket of peer client (or -1 if not connected yet)
} ClientData;

void *client_handler(void *arg) {
    ClientData *data = (ClientData *)arg;
    char buffer[BUF_SIZE];
    int bytes_read;

    printf("Client %d handler started.\n", data->id);

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        bytes_read = recv(data->socket, buffer, sizeof(buffer) - 1, 0);
        if (bytes_read <= 0) {
            printf("Client %d disconnected.\n", data->id);
            break;
        }

        buffer[bytes_read] = '\0';
        printf("Message from Client %d: %s\n", data->id, buffer);

        // If peer is connected, forward the message
        if (data->peer_socket != -1) {
            send(data->peer_socket, buffer, strlen(buffer), 0);
        } else {
            const char *msg = "Peer not connected yet.\n";
            send(data->socket, msg, strlen(msg), 0);
        }
    }

    close(data->socket);
    free(data);
    return NULL;
}

int main(int argc, char *argv[]) {
    int port = PORT;
    if (argc >= 2) {
        port = atoi(argv[1]);
    }

    int server_fd, client_fd[MAX_CLIENTS];
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);
    pthread_t threads[MAX_CLIENTS];
    ClientData *client_data[MAX_CLIENTS] = {NULL, NULL};

    // 1. Create server socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // 2. Bind to port
    memset(&address, 0, sizeof(address));
    address.sin_family      = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port        = htons(port);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // 3. Listen
    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("listen");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server5 listening on port %d...\n", port);

    int connected_clients = 0;
    while (connected_clients < MAX_CLIENTS) {
        client_fd[connected_clients] =
            accept(server_fd, (struct sockaddr *)&address, &addrlen);
        if (client_fd[connected_clients] < 0) {
            perror("accept");
            continue;
        }

        printf("Client %d connected.\n", connected_clients + 1);

        client_data[connected_clients] = malloc(sizeof(ClientData));
        client_data[connected_clients]->socket = client_fd[connected_clients];
        client_data[connected_clients]->id     = connected_clients + 1;
        client_data[connected_clients]->peer_socket =
            (connected_clients == 0) ? -1 : client_fd[0];

        // Once second client connects, set peer for first client
        if (connected_clients == 1 && client_data[0] != NULL) {
            client_data[0]->peer_socket = client_fd[1];
        }

        if (pthread_create(&threads[connected_clients], NULL,
                           client_handler, client_data[connected_clients]) != 0) {
            perror("pthread_create");
            close(client_fd[connected_clients]);
            free(client_data[connected_clients]);
            client_data[connected_clients] = NULL;
        } else {
            connected_clients++;
        }
    }

    // Wait for threads to finish
    for (int i = 0; i < connected_clients; i++) {
        pthread_join(threads[i], NULL);
    }

    close(server_fd);
    printf("Server5 shutting down.\n");
    return 0;
}`