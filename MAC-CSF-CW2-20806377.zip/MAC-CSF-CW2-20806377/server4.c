// Server4.c (macOS / POSIX)
// Task 4: handle:
//   "Time"       -> return current Malaysia time (HH:MM:SS\r\n)
//   "Time <TZ>"  -> return current time for that timezone (Table 1 offsets)
// Any other input -> error message (as in tasks 1-3).
// Only terminate if client sends exactly: "Exit Server"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024
#define DEFAULT_PORT 8080

typedef struct {
    const char *code;
    int offset_from_gmt;
} TimeZone;

static const TimeZone timeZones[] = {
    {"PST", -8},
    {"MST", -7},
    {"CST", -6},
    {"EST", -5},
    {"GMT",  0},
    {"CET", +1},
    {"MSK", +3},
    {"JST", +9},
    {"AEDT", +11}
};

static void strip_crlf(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[n - 1] = '\0';
        n--;
    }
}

static int find_offset(const char *code, int *out_offset) {
    for (size_t i = 0; i < sizeof(timeZones) / sizeof(timeZones[0]); i++) {
        if (strcmp(code, timeZones[i].code) == 0) {
            *out_offset = timeZones[i].offset_from_gmt;
            return 1;
        }
    }
    return 0;
}

static void format_time_from_utc_offset(char *out, size_t out_sz, int offset_hours) {
    time_t now = time(NULL);
    struct tm *utc = gmtime(&now);

    // adjust hours then normalise with mktime()
    utc->tm_hour += offset_hours;
    mktime(utc);

    char tmp[64];
    strftime(tmp, sizeof(tmp), "%H:%M:%S", utc);
    snprintf(out, out_sz, "%s\r\n", tmp);
}

int main(int argc, char *argv[]) {
    int port = DEFAULT_PORT;
    if (argc >= 2) port = atoi(argv[1]);

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((uint16_t)port);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 3) < 0) {
        perror("listen");
        close(server_fd);
        return 1;
    }

    printf("Server4 listening on port %d...\n", port);

    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);

    while (1) {
        int client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) { perror("accept"); continue; }

        // Keep Task 2 style info (Server4 builds on Server3/Server2)
        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &client_addr.sin_addr, ip, sizeof(ip));
        printf("Connected client IP: %s\n", ip);
        printf("Client port: %d\n", ntohs(client_addr.sin_port));

        char buffer[BUF_SIZE];

        while (1) {
            memset(buffer, 0, sizeof(buffer));
            int bytes = (int)recv(client_fd, buffer, sizeof(buffer) - 1, 0);
            if (bytes <= 0) {
                printf("Client disconnected.\n");
                break;
            }

            buffer[bytes] = '\0';
            strip_crlf(buffer);

            printf("Length of message: %zu\n", strlen(buffer));
            printf("Received: %s\n", buffer);

            if (strcmp(buffer, "Exit Server") == 0) {
                const char *bye = "Server closed the connection.\r\n";
                send(client_fd, bye, (int)strlen(bye), 0);
                printf("Exit Server received. Shutting down Server4.\n");
                close(client_fd);
                close(server_fd);
                return 0;
            }

            // Parse "Time" and optional timezone
            char copy[BUF_SIZE];
            strncpy(copy, buffer, sizeof(copy) - 1);
            copy[sizeof(copy) - 1] = '\0';

            char *cmd = strtok(copy, " ");
            char *tz  = strtok(NULL, " ");

            if (cmd && strcmp(cmd, "Time") == 0) {
                char out[64];

                if (!tz) {
                    // Malaysia time is GMT + 8
                    format_time_from_utc_offset(out, sizeof(out), +8);
                    send(client_fd, out, (int)strlen(out), 0);
                    printf("Sent Malaysia time: %s", out);
                } else {
                    int offset;
                    if (!find_offset(tz, &offset)) {
                        const char *err =
                            "Error: Invalid input. Please key in an alphanumeric format message only.\r\n";
                        send(client_fd, err, (int)strlen(err), 0);
                        printf("Invalid timezone code: %s\n", tz);
                    } else {
                        format_time_from_utc_offset(out, sizeof(out), offset);
                        send(client_fd, out, (int)strlen(out), 0);
                        printf("Sent %s time: %s", tz, out);
                    }
                }
                continue;
            }

            const char *err =
                "Error: Invalid input. Please key in an alphanumeric format message only.\r\n";
            send(client_fd, err, (int)strlen(err), 0);
            printf("Sent error to client.\n");
        }

        close(client_fd);
    }
}