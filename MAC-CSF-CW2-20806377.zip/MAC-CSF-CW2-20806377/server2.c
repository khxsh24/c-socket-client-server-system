// Server2.c  (Mac / POSIX version)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUF_SIZE 1024

// Function to check if the message is alphanumeric or space
int is_alphanumeric(const char *message) {
    for (int i = 0; message[i] != '\0'; i++) {
        if (!isalnum((unsigned char)message[i]) && message[i] != ' ') {
            return 0;
        }
    }
    return 1;
}

int main(int argc, char *argv[]) {
    int port = PORT;
    if (argc >= 2) port = atoi(argv[1]);

    int server_fd, new_socket;
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);
    char buffer[BUF_SIZE] = {0};

    // 1. Create the socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // 2. Bind the socket to an IP/Port
    memset(&address, 0, sizeof(address));
    address.sin_family      = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port        = htons(port);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    while (1) {
        // 3. Listen for incoming connections
        if (listen(server_fd, 3) < 0) {
            perror("listen");
            close(server_fd);
            exit(EXIT_FAILURE);
        }
        printf("Server2 listening on port %d...\n", port);

        // 4. Accept a connection
        new_socket = accept(server_fd, (struct sockaddr *)&address, &addrlen);
        if (new_socket == -1) {
            perror("accept");
            continue;
        }

        // Display client information (only once per connection)
        char client_ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &address.sin_addr, client_ip, INET_ADDRSTRLEN);
        printf("Connected to client:\n");
        printf("IP address: %s\n", client_ip);
        printf("Port number: %d\n", ntohs(address.sin_port));

        // 5. loop to handle multiple inputs from this client
        while (1) {
            memset(buffer, 0, sizeof(buffer));
            int bytes_received = recv(new_socket, buffer, sizeof(buffer) - 1, 0);
            if (bytes_received <= 0) {
                printf("Connection closed by client.\n");
                break;
            }

            buffer[bytes_received] = '\0';

            printf("Length of message: %ld\n", strlen(buffer));
            printf("Received message from the client: %s\n", buffer);

            // Check if the client wants to exit
            if (strcmp(buffer, "Exit Server") == 0) {
                printf("Client requested to close the connection...\n");
                const char *msg = "Server closed the connection.";
                send(new_socket, msg, strlen(msg), 0);
                break;
            }

            // call function
            if (!is_alphanumeric(buffer)) {
                const char *error_message = "Error: Only alphanumeric messages are allowed.";
                send(new_socket, error_message, strlen(error_message), 0);
                printf("Sent error message to client: %s\n", error_message);
                continue;
            }

            // Echo back the valid message
            send(new_socket, buffer, strlen(buffer), 0);
            printf("Sent back to client: %s\n", buffer);
        }

        close(new_socket);
    }

    close(server_fd);
    return 0;
}